///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//
//  STUDENT: Nathan Perry
//  ASSIGNMENT: Final Project - 3D Desk Scene
//  DESCRIPTION: Final version of the 3D desk scene. Builds on the lighting
//               work from Milestone Five by adding desktop accessories that
//               bring the scene closer to the reference photo and satisfy
//               the final project's shape-variety and object-count rubric
//               requirements.
//
//  SCENE COMPONENTS:
//  - 1 plane for the ground/floor surface (stone paver texture, TILED)
//  - 1 desk (7 boxes):
//      - 1 desktop surface (rustic wood texture)
//      - 6 pieces for the U-frame legs (brushed gold metal texture)
//  - 1 iMac monitor (4 primitives):
//      - 1 box for the base (plastic material)
//      - 1 tapered cylinder for the curved neck (plastic material)
//      - 1 box for the outer frame/bezel (plastic material)
//      - 1 box for the inner screen (galaxy texture, screen material)
//  - 1 keyboard (2 primitives: body + raised keys cluster, steel texture)
//  - 1 mouse (sphere scaled flat, plastic material)

//  SHAPE TYPES USED (4 required, 4 present): Box, Plane, Tapered Cylinder,
//  and Sphere.
//
//  TEXTURES USED:
//  - pavers:  ground plane (tiled 4x4)
//  - wood:    desk top (tiled 2x1)
//  - metal:   desk leg frames (tiled per-piece)
//  - galaxy:  iMac display (not tiled)
//  - steel:   iMac body (base/neck/frame) + keyboard (body + keys)
//
//  LIGHTING DESIGN (FINAL):
//  - Light 0 (KEY): Warm tungsten, above/front-right - the "desk lamp"
//  - Light 1 (FILL): Dim cool, back-left - prevents complete shadow
//  - Light 2 (GLOW): Warm amber, high above desk center - adds the cozy
//    overhead glow Nathan wanted to echo the reference photo's mood
//  - Light 3: Explicitly zeroed (shader loops over all 4 slots)
//
//  MATERIAL DESIGN (FINAL):
//  - "floor":   Matte stone, soft specular
//  - "wood":    Finished wood, moderate specular sheen
//  - "metal":   Brushed gold, high specular with warm highlight tint
//  - "plastic": Matte white-ish plastic/aluminum for monitor body,
//               keyboard, and mouse (all similar surfaces in reference)
//  - "screen":  Very dark base with sharp glossy highlight for the
//               iMac display glass
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(bFound);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 *
 *  HOW IT WORKS:
 *  1. Sets bUseTexture to true in the fragment shader, which
 *     tells the shader to sample from a texture instead of
 *     using a solid color
 *  2. Looks up the texture slot index by tag name
 *  3. Passes that index to the shader's sampler2D uniform
 *
 *  WHY WE USE TAGS:
 *  String tags like "wood" or "metal" are easier to remember
 *  than numeric indices, making the code more readable in
 *  RenderScene() when applying textures to objects.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 *
 *  HOW IT WORKS:
 *  UV coordinates normally range from 0 to 1 across a surface.
 *  By setting a UV scale > 1, the texture repeats (tiles) that
 *  many times across the surface. For example:
 *    - UV scale (1, 1) = texture appears once
 *    - UV scale (4, 4) = texture tiles 4x4 = 16 times
 *
 *  WHY IT'S IMPORTANT:
 *  Large surfaces like the ground plane would look pixelated
 *  and stretched if the texture only appeared once. Tiling
 *  creates a seamless, realistic appearance with proper
 *  texture density. This is a "complex texturing technique"
 *  as required by the rubric.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  DefineObjectMaterials()  [MILESTONE FIVE]
 *
 *  This method populates the m_objectMaterials list with the
 *  Phong material data for every surface type in the scene.
 *  Each material is looked up by tag from RenderScene() via
 *  SetShaderMaterial(), which pushes the values into the
 *  fragment shader's "material" uniform struct.
 *
 *  WHY MATERIALS MATTER:
 *  Textures give a surface its *color pattern*, but materials
 *  tell the shader *how that surface reacts to light* - how
 *  matte or shiny it is, what color its highlights are, and
 *  how much ambient light it absorbs. Without materials set,
 *  the shader receives zeroed uniforms and every surface
 *  looks flat and unlit, even with lights defined.
 *
 *  NOTE ON SHININESS SCALE:
 *  In this project's fragment shader, material.shininess is
 *  used as a scalar multiplier on the specular contribution
 *  (not as the Phong exponent). The Phong exponent actually
 *  lives in each light's focalStrength. So shininess values
 *  here are small scalars (~0.3 to ~0.9), not 32/64/128 as in
 *  conventional Phong tutorials.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// ============ FLOOR (STONE PAVERS) ============
	// Matte stone - reflects some light but not glossy. The low
	// specular keeps the floor from looking wet or polished, while
	// still satisfying the rubric's "reflect light off a plane"
	// requirement.
	OBJECT_MATERIAL floorMaterial;
	floorMaterial.tag = "floor";
	floorMaterial.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
	floorMaterial.ambientStrength = 0.2f;
	floorMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	floorMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
	floorMaterial.shininess = 0.3f;
	m_objectMaterials.push_back(floorMaterial);

	// ============ WOOD (DESKTOP) ============
	// Finished/sealed wood - warm tones with a moderate sheen.
	// The warm diffuse tint complements the rustic wood texture
	// under the warm key light; the moderate specular gives the
	// impression of a lacquered or oiled finish.
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.tag = "wood";
	woodMaterial.ambientColor = glm::vec3(0.3f, 0.2f, 0.1f);
	woodMaterial.ambientStrength = 0.2f;
	woodMaterial.diffuseColor = glm::vec3(0.6f, 0.45f, 0.3f);
	woodMaterial.specularColor = glm::vec3(0.35f, 0.3f, 0.25f);
	woodMaterial.shininess = 0.4f;
	m_objectMaterials.push_back(woodMaterial);

	// ============ METAL (BRUSHED GOLD LEG FRAMES) ============
	// High shininess with warm gold-tinted specular highlights.
	// This is the material that sells the "warm desk lamp" mood:
	// the gold catches the tungsten key light dramatically and
	// gives the frames a polished metal feel.
	OBJECT_MATERIAL metalMaterial;
	metalMaterial.tag = "metal";
	metalMaterial.ambientColor = glm::vec3(0.25f, 0.2f, 0.1f);
	metalMaterial.ambientStrength = 0.3f;
	metalMaterial.diffuseColor = glm::vec3(0.75f, 0.6f, 0.3f);
	metalMaterial.specularColor = glm::vec3(1.0f, 0.85f, 0.5f);
	metalMaterial.shininess = 0.9f;
	m_objectMaterials.push_back(metalMaterial);

	// ============ PLASTIC (IMAC BODY, KEYBOARD, MOUSE) [FINAL PROJECT] ============
	// Cool silver-gray with a moderately strong aluminum-style specular.
	// Used for all non-screen parts of the monitor as well as the keyboard
	// and mouse. The reference photo shows these parts as Apple's signature
	// brushed-aluminum finish, so the material is tuned to read as metal
	// rather than white plastic:
	//   - Diffuse pushed slightly blue-cool so the base color reads as
	//     aluminum instead of ivory/cream under the warm scene lighting.
	//   - Specular pushed up and given a faint cool tint so highlights
	//     feel like light glinting off a metal surface instead of the
	//     duller reflection a matte plastic would produce.
	//   - Shininess raised so the highlight hits harder, which is what
	//     sells "polished aluminum" vs. "flat paint" at a glance.
	// The tag name "plastic" is kept unchanged for code continuity even
	// though the material now represents aluminum - swapping the values
	// without renaming means no RenderScene() draw calls need updating.
	OBJECT_MATERIAL plasticMaterial;
	plasticMaterial.tag = "plastic";
	plasticMaterial.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
	plasticMaterial.ambientStrength = 0.25f;
	plasticMaterial.diffuseColor = glm::vec3(0.72f, 0.74f, 0.78f);
	plasticMaterial.specularColor = glm::vec3(0.75f, 0.78f, 0.85f);
	plasticMaterial.shininess = 0.85f;
	m_objectMaterials.push_back(plasticMaterial);

	// ============ SCREEN (IMAC DISPLAY GLASS) [FINAL PROJECT] ============
	// Very dark base with a sharp, bright specular highlight - the optical
	// behavior of glass over a dark LCD. The diffuse is kept low so the
	// galaxy texture's own colors come through clearly without being washed
	// out by the warm lighting; the high specular color plus high shininess
	// lets the screen catch a crisp reflection from the overhead amber light,
	// which sells the "it's glass" read at a glance.
	OBJECT_MATERIAL screenMaterial;
	screenMaterial.tag = "screen";
	screenMaterial.ambientColor = glm::vec3(0.05f, 0.05f, 0.08f);
	screenMaterial.ambientStrength = 0.4f;
	screenMaterial.diffuseColor = glm::vec3(0.4f, 0.4f, 0.45f);
	screenMaterial.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
	screenMaterial.shininess = 1.0f;
	m_objectMaterials.push_back(screenMaterial);
}

/***********************************************************
 *  SetupSceneLights()  [MILESTONE FIVE - EXPANDED FOR FINAL]
 *
 *  This method configures the fragment shader's lightSources[]
 *  array and turns on the bUseLighting flag. The shader has 4
 *  light slots; this scene uses 3 and explicitly zeros the
 *  remaining slot (otherwise uninitialized uniform memory could
 *  add phantom light to the scene).
 *
 *  LIGHTING MOOD: Warm, dim, relaxed office.
 *  Picture working late at a desk with a single warm lamp on
 *  and faint cool light spilling in from another room, plus a
 *  warm overhead glow pouring down onto the work surface.
 *
 *  LIGHT 0 - KEY (desk lamp, warm tungsten):
 *    Positioned above and in front of the desk, angled down.
 *    Warm orange-yellow diffuse with a warm specular that
 *    will catch the gold frames nicely.
 *
 *  LIGHT 1 - FILL (ambient room bleed, cool):
 *    Positioned opposite the key on the back-left. Dim and
 *    slightly cool-tinted to simulate indirect/bounced light.
 *    Its main job is to satisfy the rubric requirement that
 *    "nothing should be in complete shadow" - it keeps the
 *    back-left of the desk legible without fighting the key.
 *
 *  LIGHT 2 - GLOW (overhead amber, FINAL PROJECT):
 *    Hanging high above the center of the desk, pointing down.
 *    Pushed oranger than the tungsten key so it reads as its
 *    own distinct light source. This is the scene's explicit
 *    "colored light" per the final project rubric.
 *
 *  UNIFORM NAMING:
 *  Names like "lightSources[0].position" must match exactly
 *  what the fragment shader declares. The shader uses an
 *  array of LightSource structs, so each field is addressed
 *  by index and dot-notation.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// ============ LIGHT 0: WARM KEY LIGHT (DESK LAMP) ============
	// Above and to the front-right of the desk, angled toward the
	// desktop - roughly where a swing-arm desk lamp would sit.
	m_pShaderManager->setVec3Value("lightSources[0].position",
		glm::vec3(1.5f, 5.0f, 2.0f));
	// Very low warm ambient - we want the scene dim, not black
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor",
		glm::vec3(0.05f, 0.04f, 0.02f));
	// Warm tungsten diffuse (~2700K look) - this is the scene's dominant color
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor",
		glm::vec3(0.9f, 0.6f, 0.35f));
	// Warm specular so highlights on the gold frames feel cohesive
	m_pShaderManager->setVec3Value("lightSources[0].specularColor",
		glm::vec3(1.0f, 0.85f, 0.6f));
	// focalStrength = Phong exponent in this shader; 32 is moderate sharpness
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 32.0f);
	// specularIntensity dials overall highlight strength
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.8f);

	// ============ LIGHT 1: COOL FILL LIGHT (ROOM BLEED) ============
	// Back-left and elevated. Dim and slightly cool-tinted to
	// contrast against the warm key, which makes the warm key read
	// as warmer by comparison. Prevents complete shadow on the
	// back side of the desk.
	m_pShaderManager->setVec3Value("lightSources[1].position",
		glm::vec3(-4.0f, 4.0f, -3.0f));
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor",
		glm::vec3(0.08f, 0.08f, 0.10f));
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor",
		glm::vec3(0.25f, 0.25f, 0.30f));
	m_pShaderManager->setVec3Value("lightSources[1].specularColor",
		glm::vec3(0.2f, 0.2f, 0.25f));
	// Lower focalStrength = broader, softer highlights (fill shouldn't pop)
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 16.0f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.3f);

	// ============ LIGHT 2: WARM AMBER OVERHEAD GLOW (FINAL PROJECT) ============
	// High above the center of the desk, pointing straight down. This light
	// was added for the final submission to echo the warm overhead glow
	// visible in the reference photo - a single amber point-source hanging
	// over the work surface like an exposed Edison bulb.
	//
	// Why amber specifically: the reference photo has a distinctly warm
	// top-down glow on the desktop surface. Using amber (pushed oranger
	// than the Light 0 tungsten key) gives this light a clearly separate
	// read so the viewer perceives TWO warm sources contributing rather
	// than just one.
	//
	// RUBRIC NOTE:
	// This explicitly satisfies the "at least one colored light" rubric
	// requirement - amber is unambiguously colored, not just tinted white.
	// Combined with the positional shader math (no directional vector, the
	// light radiates from a point in world space), this also gives the
	// scene its required point light.
	m_pShaderManager->setVec3Value("lightSources[2].position",
		glm::vec3(0.0f, 7.0f, 0.5f));
	// Very low ambient so the floor doesn't glow orange
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor",
		glm::vec3(0.04f, 0.025f, 0.01f));
	// Deep amber diffuse - oranger than Light 0 so the two warm sources
	// don't visually collapse into one. Tuned down substantially from the
	// initial (1.0, 0.55, 0.15) in multiple passes - the overhead light
	// was washing out the textures on the desktop and on object tops.
	// The current value is roughly a quarter of the original intensity
	// while preserving the amber color ratio.
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor",
		glm::vec3(0.25f, 0.13f, 0.04f));
	// Warm amber specular tints highlights on the desktop and screen
	m_pShaderManager->setVec3Value("lightSources[2].specularColor",
		glm::vec3(1.0f, 0.7f, 0.3f));
	// focalStrength = Phong exponent. 24 sits between the key (32) and the
	// fill (16) - slightly softer highlight than the key so the glow feels
	// diffused rather than pin-sharp
	m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 24.0f);
	// Low specular intensity - the overhead light should add color
	// atmosphere rather than hot highlights on object tops. The key light
	// (Light 0) is the primary source of specular "pop" in the scene.
	m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.15f);

	// ============ LIGHT 3: EXPLICITLY DISABLED ============
	// The fragment shader's main loop iterates all 4 slots. If we leave
	// this uninitialized it can contain garbage values that quietly
	// brighten the scene. Zeroing every field guarantees zero contribution
	// from this unused slot.
	{
		std::string base = "lightSources[3].";
		m_pShaderManager->setVec3Value(base + "position", glm::vec3(0.0f));
		m_pShaderManager->setVec3Value(base + "ambientColor", glm::vec3(0.0f));
		m_pShaderManager->setVec3Value(base + "diffuseColor", glm::vec3(0.0f));
		m_pShaderManager->setVec3Value(base + "specularColor", glm::vec3(0.0f));
		m_pShaderManager->setFloatValue(base + "focalStrength", 1.0f);
		m_pShaderManager->setFloatValue(base + "specularIntensity", 0.0f);
	}

	// ============ ENABLE LIGHTING IN THE FRAGMENT SHADER ============
	// Without this flag, the shader's main() takes the else branch
	// and ignores all the material/light uniforms entirely. This is
	// the single switch that activates everything above.
	// NOTE: This project routes bool uniforms through setIntValue()
	// (same pattern used for bUseTexture elsewhere in this file),
	// because GLSL bools map to integer uniforms at the C++/GL layer.
	m_pShaderManager->setIntValue(g_UseLightingName, true);
}

/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method is used for loading the textures that will
 *  be applied to the 3D scene objects.
 *
 *  HOW TEXTURE LOADING WORKS:
 *  1. CreateGLTexture() uses stb_image to load the JPG file
 *  2. Creates an OpenGL texture object with glGenTextures()
 *  3. Configures wrapping (GL_REPEAT) and filtering (GL_LINEAR)
 *  4. Uploads the image data to the GPU with glTexImage2D()
 *  5. Generates mipmaps for efficient rendering at distances
 *  6. Stores the texture ID with a string tag for later lookup
 *
 *  WHY I CHOSE THESE TEXTURES:
 *  - Wood texture for desktop: Matches the brown wooden surface
 *    visible in the reference photo of my desk
 *  - Brushed gold metal for legs: Creates a metallic appearance
 *    for the U-shaped leg frames that matches metal furniture
 *  - Stone pavers for floor: Provides a neutral ground surface
 *    that contrasts with the desk without being distracting
 *
 *  TEXTURE FILE PATH:
 *  The path "../../Utilities/textures/" is relative to the
 *  executable location in the Debug/Release folder. This goes
 *  up two directories to the CS330Content folder, then into
 *  the Utilities/textures subfolder.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	// ============ LOAD GROUND PLANE TEXTURE ============
	// Gray stone pavers - this seamless tileable texture will
	// repeat across the large ground surface. I chose this
	// because it provides a neutral base that doesn't compete
	// visually with the desk, and it demonstrates texture tiling.
	CreateGLTexture("../../Utilities/textures/pavers.jpg", "pavers");

	// ============ LOAD DESKTOP TEXTURE ============
	// Rustic wood grain - the horizontal grain pattern matches
	// the natural look of a wooden desk surface. The warm brown
	// tones closely match my reference photo.
	CreateGLTexture("../../Utilities/textures/rusticwood.jpg", "wood");

	// ============ LOAD LEG FRAME TEXTURE ============
	// Circular brushed gold metal - this radial brush pattern
	// creates a realistic metallic appearance for the U-shaped
	// leg frames. The circular pattern works well on the boxy
	// leg components, giving them a manufactured metal look.
	CreateGLTexture("../../Utilities/textures/circular-brushed-gold-texture.jpg", "metal");

	// ============ LOAD IMAC SCREEN TEXTURE (FINAL PROJECT) ============
	// Galaxy/nebula image for the iMac display. The reference photo
	// shows the iMac with a space-themed wallpaper, so a galaxy image
	// is the single most recognizable way to identify the monitor as
	// an iMac once it's rendered. This is also the only texture in the
	// scene that is NOT tiled - a galaxy is a singular image, so the
	// default UV scale (1.0, 1.0) keeps the whole image visible once
	// across the screen face.
	CreateGLTexture("../../Utilities/textures/galaxy.jpg", "galaxy");

	// ============ LOAD BRUSHED STEEL TEXTURE (FINAL PROJECT) ============
	// Brushed steel image for the iMac body (base, neck, frame) and the
	// keyboard. Sits on top of the "plastic" Phong material, so the
	// material still controls how these surfaces react to light (cool
	// specular, silver-tinted diffuse) while the texture layers the
	// actual brushed-aluminum pattern on top. This gives the monitor
	// and keyboard their metal surface detail that a solid color
	// couldn't achieve.
	CreateGLTexture("../../Utilities/textures/brushsteel.jpg", "steel");

	// ============ BIND TEXTURES TO TEXTURE UNITS ============
	// After loading, each texture must be bound to a texture unit.
	// OpenGL supports up to 16 texture units (GL_TEXTURE0 through
	// GL_TEXTURE15). BindGLTextures() iterates through all loaded
	// textures and binds each one to its corresponding slot.
	// This allows the fragment shader to access multiple textures
	// during rendering by sampling from the appropriate unit.
	BindGLTextures();
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes and textures in memory to support the 3D scene
 *  rendering.
 *
 *  PREPARATION ORDER:
 *  1. Load textures first (LoadSceneTextures)
 *  2. Then load mesh geometry (LoadPlaneMesh, LoadBoxMesh)
 *
 *  WHY THIS ORDER MATTERS:
 *  Textures need to be loaded and bound to texture units before
 *  rendering begins. The mesh geometry can be loaded at any time
 *  before RenderScene() is called, but having textures ready
 *  first ensures they're available when we start drawing.
 *
 *  SHAPES LOADED:
 *  - Plane mesh: For the ground/floor surface
 *  - Box mesh: For the desk (desktop + leg frame pieces)
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// =========================================================================
	// LOAD SCENE TEXTURES
	// =========================================================================
	// Load all texture images into GPU memory and bind them to texture units.
	// This must happen before rendering so textures are available for use.
	LoadSceneTextures();

	// =========================================================================
	// LOAD PLANE MESH
	// =========================================================================
	// The plane serves as the ground/floor surface beneath the desk.
	// This is a requirement for the final project - it situates the 3D scene
	// and helps define the scope of the world the camera navigates through.
	m_basicMeshes->LoadPlaneMesh();

	// =========================================================================
	// LOAD BOX MESH
	// =========================================================================
	// The box mesh is used for the desk components:
	// - 1 desktop surface
	// - 6 leg frame pieces (2 U-frames, each with 2 vertical posts + 1 horizontal bar)
	// And for the final project additions:
	// - 1 iMac monitor base
	// - 1 iMac monitor screen
	// - 1 keyboard
	m_basicMeshes->LoadBoxMesh();

	// =========================================================================
	// LOAD TAPERED CYLINDER MESH (FINAL PROJECT)
	// =========================================================================
	// The tapered cylinder is used for the iMac monitor's curved neck.
	// It tapers from a bottom radius of 1.0 to a top radius of 0.5 over a
	// height of 1.0 - exactly the shape of an iMac's aluminum stand, which
	// is wider at the base and narrower where it meets the screen. Using a
	// plain cylinder would have given the stand a stubby, can-like look; the
	// tapered cylinder reads instantly as "monitor stand."
	m_basicMeshes->LoadTaperedCylinderMesh();

	// =========================================================================
	// LOAD SPHERE MESH (FINAL PROJECT)
	// =========================================================================
	// The sphere is used for the mouse, scaled flat on the Y axis to read
	// as a low-profile desktop mouse rather than a full ball. Scaling a
	// unit sphere down in one axis is a common trick for getting a
	// squashed-dome shape without needing a separate half-sphere mesh.
	m_basicMeshes->LoadSphereMesh();

	// =========================================================================
	// DEFINE OBJECT MATERIALS (MILESTONE FIVE)
	// =========================================================================
	// Populate the material list used by each surface. This must happen
	// before the first RenderScene() call so SetShaderMaterial() lookups
	// succeed on the very first frame.
	DefineObjectMaterials();

	// =========================================================================
	// SETUP SCENE LIGHTS (MILESTONE FIVE)
	// =========================================================================
	// Configure the key + fill light pair and enable Phong lighting in the
	// fragment shader. These uniforms are set once here because the lights
	// in this scene are static - re-sending them every frame would work but
	// would be unnecessary GPU traffic.
	SetupSceneLights();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes with textures.
 *
 *  SCENE STRUCTURE:
 *  - 1 plane for the ground/floor (stone paver texture, TILED 4x4)
 *  - 1 box for the desktop surface (rustic wood texture)
 *  - Left U-Frame: 2 vertical posts + 1 horizontal bar (metal texture)
 *  - Right U-Frame: 2 vertical posts + 1 horizontal bar (metal texture)
 *  Total: 1 plane + 7 boxes
 *
 *  TEXTURING APPROACH:
 *  For each shape, I follow this process:
 *    1. Set transformations (scale, rotate, translate)
 *    2. Call SetShaderTexture() to select which texture to use
 *    3. Call SetTextureUVScale() to control texture tiling
 *    4. Call the appropriate Draw___Mesh() method to render
 *
 *  COHESIVE OBJECT DESIGN (Rubric Requirement):
 *  The desk is a complex object made of multiple shapes with
 *  different textures that work together visually:
 *  - Desktop: Wood texture emphasizes it's a wooden surface
 *  - Leg frames: Metal texture emphasizes they're metal supports
 *  This creates visual continuity while highlighting the
 *  different materials that make up a real desk.
 *
 *  COMPLEX TEXTURING TECHNIQUE (Rubric Requirement):
 *  The ground plane uses texture TILING with UV scale (4, 4),
 *  which repeats the stone paver pattern 16 times across the
 *  surface. This prevents the texture from looking stretched
 *  and pixelated on the large plane.
 ***********************************************************/
void SceneManager::RenderScene()
{
	// Declare transformation variables used for each shape
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// ============================================================
	// GROUND PLANE (TEXTURED WITH TILING - COMPLEX TECHNIQUE)
	// ============================================================
	// The ground plane serves as the base for the 3D scene.
	// It represents the floor surface that the desk sits on.
	//
	// TEXTURE: Stone pavers ("pavers")
	// UV SCALE: (4.0, 4.0) - tiles the texture 4x4 = 16 times
	//
	// WHY TILING IS USED:
	// The ground plane is scaled to 20x20 units, which is very large.
	// If the texture only appeared once (UV scale 1,1), it would be
	// extremely stretched and pixelated. By tiling 4x4, each instance
	// of the texture covers a 5x5 unit area, maintaining good resolution.
	// This demonstrates the "complex texturing technique" required
	// by the rubric - specifically texture tiling.
	//
	// Transformations applied:
	// - SCALE: 20 x 1 x 20 to create a large floor area
	// - ROTATE: None needed (plane is already horizontal)
	// - TRANSLATE: Positioned at Y=0 (ground level)
	// ============================================================

	// Scale the plane to create a large floor surface
	scaleXYZ = glm::vec3(20.0f, 1.0f, 20.0f);

	// No rotation needed - the plane is already oriented horizontally
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position the plane at ground level (Y=0), centered on X and Z
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// Apply all transformations
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// Apply stone paver texture with tiling
	// SetShaderTexture tells the shader to use texture mode
	// SetTextureUVScale(4, 4) makes the texture repeat 4 times in each direction
	// Apply Phong material for this surface (Milestone Five)
	SetShaderMaterial("floor");
	SetShaderTexture("pavers");
	SetTextureUVScale(4.0f, 4.0f);

	// Draw the ground plane
	m_basicMeshes->DrawPlaneMesh();

	// ============================================================
	// DESK DIMENSIONS (based on reference image proportions)
	// ============================================================
	// Desktop: wide (X), thin (Y), moderate depth (Z)
	// The reference image shows approximately 5:1 width-to-depth ratio
	// 
	// IMPORTANT: In the reference photo, the U-shaped leg frames are
	// oriented so they run FRONT-TO-BACK (along Z axis), with one frame
	// at the far LEFT edge and one at the far RIGHT edge of the desk.

	float desktopWidth = 10.0f;    // X dimension - full width of desk
	float desktopThickness = 0.3f; // Y dimension - thickness of wooden top
	float desktopDepth = 4.0f;     // Z dimension - front to back
	float desktopHeight = 2.85f;    // Y position of desktop surface

	// Leg frame dimensions
	// Each U-frame has two vertical posts (front and back) connected by a bottom bar
	float legPostWidth = 0.3f;     // X dimension of vertical posts
	float legPostDepth = 0.3f;     // Z dimension of vertical posts
	float legPostHeight = 2.7f;    // Y dimension - height from floor to bottom of desktop

	float legBarHeight = 0.3f;     // Y dimension of horizontal bar
	float legBarWidth = 0.3f;      // X dimension of horizontal bar
	float legFrameSpan = 3.0f;     // Z distance between the two vertical posts (front to back)

	// Positioning
	float legFrameInset = 0.3f;    // How far leg frames are inset from desktop edge (X direction)

	// Calculate X positions for left and right frames (near the edges)
	float leftFrameX = -(desktopWidth / 2.0f) + legFrameInset + (legPostWidth / 2.0f);
	float rightFrameX = (desktopWidth / 2.0f) - legFrameInset - (legPostWidth / 2.0f);

	// ============================================================
	// PART 1: DESKTOP SURFACE (WOOD TEXTURE)
	// ============================================================
	// The desktop is a wide, thin box representing the wooden surface.
	//
	// TEXTURE: Rustic wood grain ("wood")
	// UV SCALE: (2.0, 1.0) - stretches texture to match desk proportions
	//
	// WHY THIS UV SCALE:
	// The desktop is 10 units wide (X) and 4 units deep (Z).
	// Using UV scale (2.0, 1.0) tiles the wood grain twice along
	// the width, which makes the grain pattern appropriately sized
	// and prevents it from looking too stretched or too busy.
	//
	// Transformations applied:
	// - SCALE: Stretch to desktop dimensions (10 x 0.3 x 4)
	// - ROTATE: None needed (box is already axis-aligned)
	// - TRANSLATE: Position at center, raised to desktop height
	// ============================================================

	// Scale the box to desktop dimensions
	scaleXYZ = glm::vec3(desktopWidth, desktopThickness, desktopDepth);

	// No rotation needed - the desktop sits flat
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position the desktop
	positionXYZ = glm::vec3(0.0f, desktopHeight, 0.0f);

	// Apply all transformations
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// Apply rustic wood texture
	// UV scale (2, 1) tiles the wood grain twice along the width
	// This creates an appropriate grain density for the desk size
	// Apply Phong material for this surface (Milestone Five)
	SetShaderMaterial("wood");
	SetShaderTexture("wood");
	SetTextureUVScale(2.0f, 1.0f);

	// Draw the desktop
	m_basicMeshes->DrawBoxMesh();

	// ============================================================
	// PART 2: LEFT U-FRAME - FRONT VERTICAL POST (METAL TEXTURE)
	// ============================================================
	// This is the front vertical post of the left leg frame.
	// The frame is at the LEFT EDGE of the desk, running front-to-back.
	//
	// TEXTURE: Circular brushed gold metal ("metal")
	// UV SCALE: (1.0, 3.0) - adjusted for vertical post proportions
	//
	// WHY THIS UV SCALE:
	// The vertical posts are tall and thin (0.3 x 2.7 x 0.3 units).
	// Using UV scale (1.0, 3.0) tiles the texture 3 times vertically,
	// which prevents the brushed metal pattern from being stretched
	// along the height of the post. This maintains the texture's
	// intended appearance and creates visual continuity with the
	// horizontal bars that use different UV scaling.
	//
	// WHY METAL TEXTURE:
	// The leg frames in my reference photo are made of metal.
	// The brushed gold texture provides a metallic appearance
	// that contrasts with the wooden desktop, creating visual
	// distinction between the different desk components. This
	// demonstrates the "cohesive object with different textures"
	// requirement - wood for the work surface, metal for support.
	//
	// Transformations applied:
	// - SCALE: Thin in X and Z, tall in Y (0.3 x 2.7 x 0.3)
	// - ROTATE: None needed
	// - TRANSLATE: Position at left edge of desk, front side
	// ============================================================

	// Scale to vertical post dimensions
	scaleXYZ = glm::vec3(legPostWidth, legPostHeight, legPostDepth);

	// No rotation needed
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position: left edge of desk, front post
	float frontPostZ = legFrameSpan / 2.0f;
	float backPostZ = -legFrameSpan / 2.0f;

	positionXYZ = glm::vec3(
		leftFrameX,                       // Left edge of desk
		legPostHeight / 2.0f,             // Centered vertically (bottom at Y=0)
		frontPostZ                        // Front position
	);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// Apply brushed metal texture with vertical tiling
	// UV scale (1, 3) tiles vertically to match the tall, thin post shape
	// Apply Phong material for this surface (Milestone Five)
	SetShaderMaterial("metal");
	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 3.0f);

	m_basicMeshes->DrawBoxMesh();

	// ============================================================
	// PART 3: LEFT U-FRAME - BACK VERTICAL POST (METAL TEXTURE)
	// ============================================================
	// This is the back vertical post of the left leg frame.
	// Same dimensions and texture as the front post, positioned at back.
	//
	// TEXTURE: Circular brushed gold metal ("metal")
	// UV SCALE: (1.0, 3.0) - matches front post for visual continuity
	//
	// WHY MATCHING UV SCALE MATTERS:
	// Both vertical posts in the same U-frame should have identical
	// texture scaling so they look like parts of the same structure.
	// This creates visual continuity within the leg frame, which is
	// important for the "cohesive object" rubric requirement.
	//
	// Transformations applied:
	// - SCALE: Same as front post (0.3 x 2.7 x 0.3)
	// - ROTATE: None needed
	// - TRANSLATE: Same X, shifted to back Z position
	// ============================================================

	// Same scale as previous post
	scaleXYZ = glm::vec3(legPostWidth, legPostHeight, legPostDepth);

	// No rotation needed
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position: same X as front post, but at the back Z position
	positionXYZ = glm::vec3(
		leftFrameX,                       // Same X as front post
		legPostHeight / 2.0f,             // Same Y as front post
		backPostZ                         // Back position
	);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// Apply same brushed metal texture with matching UV scale
	// Apply Phong material for this surface (Milestone Five)
	SetShaderMaterial("metal");
	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 3.0f);

	m_basicMeshes->DrawBoxMesh();

	// ============================================================
	// PART 4: LEFT U-FRAME - HORIZONTAL BOTTOM BAR (METAL TEXTURE)
	// ============================================================
	// This bar connects the front and back vertical posts at the bottom.
	// It runs along the Z axis (front to back).
	//
	// TEXTURE: Circular brushed gold metal ("metal")
	// UV SCALE: (1.0, 2.0) - adjusted for horizontal bar proportions
	//
	// WHY THIS UV SCALE:
	// The horizontal bar is thin but long (0.3 x 0.3 x ~3.3 units).
	// Using UV scale (1.0, 2.0) tiles the texture twice along its
	// length, which maintains proper texture density and prevents
	// the brushed metal pattern from appearing stretched. This
	// different UV scale from the vertical posts is intentional -
	// the bar runs in a different direction, so texture scaling
	// needs to adapt to maintain visual quality.
	//
	// VISUAL CONTINUITY:
	// Even though the UV scale differs from the vertical posts,
	// using the same "metal" texture tag ensures all leg frame
	// pieces share the same brushed gold appearance, creating
	// a cohesive metal structure.
	//
	// Transformations applied:
	// - SCALE: Thin in X and Y, spans Z distance between posts
	// - ROTATE: None needed
	// - TRANSLATE: Positioned at bottom, connecting front and back posts
	// ============================================================

	// Calculate the length of the bar
	float horizontalBarLength = legFrameSpan + legPostDepth;

	// Scale to horizontal bar dimensions (runs along Z axis)
	scaleXYZ = glm::vec3(legBarWidth, legBarHeight, horizontalBarLength);

	// No rotation needed
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position: at left frame X, centered between front and back posts, at the bottom
	positionXYZ = glm::vec3(
		leftFrameX,                       // Same X as the vertical posts
		legBarHeight / 2.0f,              // Just above floor
		0.0f                              // Centered between front and back
	);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// Apply brushed metal texture with horizontal tiling
	// UV scale (1, 2) tiles along length for proper texture density
	// Apply Phong material for this surface (Milestone Five)
	SetShaderMaterial("metal");
	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 2.0f);

	m_basicMeshes->DrawBoxMesh();

	// ============================================================
	// PART 5: RIGHT U-FRAME - FRONT VERTICAL POST (METAL TEXTURE)
	// ============================================================
	// This is the front vertical post of the right leg frame.
	// The frame is at the RIGHT EDGE of the desk, running front-to-back.
	//
	// TEXTURE: Circular brushed gold metal ("metal")
	// UV SCALE: (1.0, 3.0) - matches left frame posts for symmetry
	//
	// WHY SYMMETRICAL UV SCALING:
	// The right U-frame should mirror the left U-frame exactly.
	// Using the same UV scale (1.0, 3.0) on all vertical posts
	// ensures both frames look identical, which is essential for
	// the desk to appear as a professionally manufactured piece
	// of furniture rather than a collection of mismatched parts.
	//
	// Transformations applied:
	// - SCALE: Same as other vertical posts (0.3 x 2.7 x 0.3)
	// - ROTATE: None needed
	// - TRANSLATE: Positioned at right edge of desk, front side
	// ============================================================

	// Same scale as other posts
	scaleXYZ = glm::vec3(legPostWidth, legPostHeight, legPostDepth);

	// No rotation needed
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position: right edge of desk, front post
	positionXYZ = glm::vec3(
		rightFrameX,                      // Right edge of desk
		legPostHeight / 2.0f,             // Same Y as other posts
		frontPostZ                        // Front position
	);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// Apply brushed metal texture with vertical tiling
	// Apply Phong material for this surface (Milestone Five)
	SetShaderMaterial("metal");
	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 3.0f);

	m_basicMeshes->DrawBoxMesh();

	// ============================================================
	// PART 6: RIGHT U-FRAME - BACK VERTICAL POST (METAL TEXTURE)
	// ============================================================
	// This is the back vertical post of the right leg frame.
	//
	// TEXTURE: Circular brushed gold metal ("metal")
	// UV SCALE: (1.0, 3.0) - consistent with all other vertical posts
	//
	// CONSISTENCY ACROSS ALL POSTS:
	// All four vertical posts (left-front, left-back, right-front,
	// right-back) use identical texture and UV scaling. This creates
	// a unified appearance across the entire leg frame structure,
	// making the desk look like a single cohesive piece of furniture.
	//
	// Transformations applied:
	// - SCALE: Same as other vertical posts (0.3 x 2.7 x 0.3)
	// - ROTATE: None needed
	// - TRANSLATE: Right edge, back position
	// ============================================================

	// Same scale as other posts
	scaleXYZ = glm::vec3(legPostWidth, legPostHeight, legPostDepth);

	// No rotation needed
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position: right edge of desk, back post
	positionXYZ = glm::vec3(
		rightFrameX,                      // Same X as front post
		legPostHeight / 2.0f,             // Same Y as other posts
		backPostZ                         // Back position
	);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// Apply brushed metal texture with vertical tiling
	// Apply Phong material for this surface (Milestone Five)
	SetShaderMaterial("metal");
	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 3.0f);

	m_basicMeshes->DrawBoxMesh();

	// ============================================================
	// PART 7: RIGHT U-FRAME - HORIZONTAL BOTTOM BAR (METAL TEXTURE)
	// ============================================================
	// This bar connects the front and back posts of the right frame.
	//
	// TEXTURE: Circular brushed gold metal ("metal")
	// UV SCALE: (1.0, 2.0) - matches left frame bar for symmetry
	//
	// HORIZONTAL BAR CONSISTENCY:
	// Both horizontal bars (left and right frames) use the same
	// UV scale (1.0, 2.0). This is different from the vertical
	// posts (1.0, 3.0) because the bars have different proportions,
	// but both bars match each other for visual symmetry.
	//
	// TEXTURE COHESION SUMMARY:
	// All 6 leg frame pieces share the same "metal" texture:
	//   - 4 vertical posts: UV scale (1.0, 3.0) for tall thin shapes
	//   - 2 horizontal bars: UV scale (1.0, 2.0) for long thin shapes
	// This creates visual continuity while adapting texture scaling
	// to each piece's unique proportions, preventing stretching.
	//
	// Transformations applied:
	// - SCALE: Same as left frame's horizontal bar
	// - ROTATE: None needed
	// - TRANSLATE: Positioned at right frame X, at the bottom
	// ============================================================

	// Same scale as left frame's bar (runs along Z axis)
	scaleXYZ = glm::vec3(legBarWidth, legBarHeight, horizontalBarLength);

	// No rotation needed
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position: at right frame X, centered between front and back, at the bottom
	positionXYZ = glm::vec3(
		rightFrameX,                      // Right frame X position
		legBarHeight / 2.0f,              // Just above floor
		0.0f                              // Centered between front and back
	);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// Apply brushed metal texture with horizontal tiling
	// Apply Phong material for this surface (Milestone Five)
	SetShaderMaterial("metal");
	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 2.0f);

	m_basicMeshes->DrawBoxMesh();

	// ============================================================
	// DESKTOP ACCESSORY DIMENSIONS (FINAL PROJECT)
	// ============================================================
	// Every object from here down sits ON TOP of the desktop.
	// The desktop surface top is at Y = desktopHeight + (desktopThickness / 2)
	// = 2.85 + 0.15 = 3.0. Centering a box on that Y value requires
	// adding half the box's Y-scale so its bottom rests flush with
	// the desktop surface.
	//
	// Object layout (matches reference photo orientation):
	//   - Monitor:   centered-left,  back half of desk (X=-1,  Z=-1)
	//   - Keyboard:  center-front                      (X=0.5, Z=1)
	//   - Mouse:     right of keyboard                 (X=2.0, Z=1)
	// ============================================================
	const float desktopSurfaceY = desktopHeight + (desktopThickness / 2.0f); // = 3.0f

	// ============================================================
	// PART 8: iMAC MONITOR BASE (PLASTIC - BOX) [FINAL PROJECT]
	// ============================================================
	// The thin, wide base plate that the monitor stand mounts to.
	// In the reference photo this is a flat aluminum disc/plate;
	// a thin box reads the same way from the front-facing camera.
	//
	// SHAPE: Box (already loaded for the desk)
	// MATERIAL: plastic (matte light surface, shared with keyboard/mouse)
	// TEXTURE: none - solid material color only
	//
	// Transformations applied:
	// - SCALE:  1.5 x 0.1 x 0.8 (wide, very thin, moderate depth)
	// - ROTATE: None
	// - TRANSLATE: Rests on desktop surface, centered at (-1, _, -1)
	// ============================================================
	scaleXYZ = glm::vec3(1.5f, 0.1f, 0.8f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Center Y sits half a scale-unit above the desktop surface so the
	// base's bottom face is flush with the wood
	positionXYZ = glm::vec3(0.5f, desktopSurfaceY + 0.05f, -1.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// Shared plastic material provides the Phong response (cool silver
	// specular + aluminum diffuse tint); the "steel" texture layered on
	// top gives the surface its brushed-metal pattern. UV scale (2, 1)
	// tiles the brushing horizontally so the pattern has appropriate
	// density on the wide/flat base.
	SetShaderMaterial("plastic");
	SetShaderTexture("steel");
	SetTextureUVScale(2.0f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	// ============================================================
	// PART 9: iMAC MONITOR NECK (PLASTIC - TAPERED CYLINDER) [FINAL PROJECT]
	// ============================================================
	// The curved aluminum stand connecting the base to the screen.
	// The iMac's signature silhouette - wider at the bottom where it
	// meets the base, narrower at the top where it meets the screen -
	// is exactly what the tapered cylinder mesh produces.
	//
	// SHAPE: Tapered cylinder (newly added for final project)
	// MATERIAL: plastic (same as base)
	//
	// WHY TAPERED CYLINDER:
	// The default tapered cylinder goes from radius 1.0 at bottom to
	// radius 0.5 at top over a height of 1.0. Scaling it by (0.4, 0.6, 0.4)
	// gives a neck that's 0.4 wide at the base, 0.2 wide at the top, and
	// 0.6 tall - proportions that match the reference iMac's stand.
	//
	// POSITIONING NOTE:
	// Tapered cylinder meshes are defined with bottom at Y=0 and top at
	// Y=height, so the position Y value corresponds to where the BOTTOM
	// of the mesh lands - NOT the center like a box. That's why this Y
	// value is different from the base's Y calculation above.
	//
	// Transformations applied:
	// - SCALE:  0.4 x 0.6 x 0.4 (narrow tapered neck)
	// - ROTATE: None (already vertical in its default orientation)
	// - TRANSLATE: Rests on top of the base at Y = 3.1
	// ============================================================
	scaleXYZ = glm::vec3(0.4f, 0.6f, 0.4f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Base top surface is at desktopSurfaceY + 0.10 = 3.10
	// Tapered cylinder bottom-Y is the placement Y, so 3.10 puts it exactly
	// on top of the base
	positionXYZ = glm::vec3(0.5f, desktopSurfaceY + 0.10f, -1.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// UV scale (1, 2) tiles vertically so the brushed pattern doesn't
	// stretch on the tall thin neck - same reasoning as the leg posts.
	SetShaderMaterial("plastic");
	SetShaderTexture("steel");
	SetTextureUVScale(1.0f, 2.0f);

	m_basicMeshes->DrawTaperedCylinderMesh();

	// ============================================================
	// PART 10A: iMAC MONITOR FRAME/BEZEL (PLASTIC - BOX) [FINAL PROJECT]
	// ============================================================
	// The outer body of the monitor - the plastic/aluminum bezel that
	// surrounds the actual display. Using plastic with no texture here
	// confines the galaxy image to JUST the visible screen area, instead
	// of having the galaxy wrap around the back and sides of the monitor.
	//
	// This pair of shapes (outer frame + inner screen in PART 10B) is
	// another multi-primitive object by the rubric's definition, which
	// further reinforces the "cohesive object using multiple primitives"
	// requirement the desk already satisfies.
	//
	// SHAPE: Box (already loaded)
	// MATERIAL: plastic (matches the monitor base and neck)
	// TEXTURE: none - solid plastic color only
	//
	// POSITIONING CALCULATION:
	// Neck top is at desktopSurfaceY + 0.10 + 0.60 = 3.70
	// Frame is 2.0 tall, so centering it above the neck puts center Y
	// at 3.70 + 1.00 = 4.70. Frame top lands at 5.70.
	//
	// Transformations applied:
	// - SCALE:  3.5 x 2.0 x 0.15 (wide, tall, very thin)
	// - ROTATE: None (+Z face points toward default camera view)
	// - TRANSLATE: Above the neck
	// ============================================================
	scaleXYZ = glm::vec3(3.5f, 2.0f, 0.15f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Neck top = desktopSurfaceY + 0.10 (base top) + 0.60 (neck height) = 3.70
	// Frame center = neck top + half frame height = 3.70 + 1.0 = 4.70
	positionXYZ = glm::vec3(0.5f, desktopSurfaceY + 0.10f + 0.60f + 1.0f, -1.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// UV scale (3, 2) tiles the brushed pattern across the largest
	// plastic-material surface in the scene. Higher horizontal count
	// matches the wider aspect of the frame without making the vertical
	// grain lines look too densely packed.
	SetShaderMaterial("plastic");
	SetShaderTexture("steel");
	SetTextureUVScale(3.0f, 2.0f);

	m_basicMeshes->DrawBoxMesh();

	// ============================================================
	// PART 10B: iMAC DISPLAY SCREEN (GALAXY TEXTURE - BOX) [FINAL PROJECT]
	// ============================================================
	// The actual display surface - a thinner, slightly smaller box sitting
	// just in front of the frame (PART 10A). The galaxy texture maps onto
	// the +Z face of this inner box, which faces the camera, while the
	// plastic frame behind it hides the wraparound on the back/sides.
	//
	// SHAPE: Box (already loaded)
	// MATERIAL: screen (dark base, sharp glossy specular)
	// TEXTURE: galaxy (UV scale 1,1 - single image across the face)
	//
	// WHY THIS APPROACH:
	// A real monitor has its display recessed inside a bezel. Rendering
	// the galaxy on the full outer box wrapped it around the whole
	// monitor body, which read as "billboard" rather than "screen."
	// Nesting a smaller textured box inside a plain plastic frame is the
	// simplest primitive combination that recreates the bezel effect.
	//
	// BEZEL SIZING:
	// Inner box scale (3.2 x 1.75 x 0.05) vs. outer frame (3.5 x 2.0 x 0.15)
	// leaves a 0.15-unit bezel on the left and right, and a 0.125-unit
	// bezel on the top and bottom - proportions close to a real iMac.
	//
	// Z POSITIONING (avoiding z-fighting):
	// The frame is centered at Z = -1.0 with depth 0.15, so its front face
	// is at Z = -0.925. Placing the inner box at Z = -0.895 with depth 0.05
	// puts its back face at Z = -0.92 (0.005 in front of the frame's front
	// face) and its front face at Z = -0.87. The small 0.005-unit gap is
	// invisible to the camera but ensures no two faces are coplanar, which
	// is what causes z-fighting flicker.
	//
	// Transformations applied:
	// - SCALE:  3.2 x 1.75 x 0.05 (smaller than frame, very thin)
	// - ROTATE: None
	// - TRANSLATE: Same X/Y as frame, Z pushed forward to avoid z-fighting
	// ============================================================
	scaleXYZ = glm::vec3(3.2f, 1.75f, 0.05f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Same X/Y as frame; Z shifted +0.105 to sit just in front of the frame
	positionXYZ = glm::vec3(
		0.5f,
		desktopSurfaceY + 0.10f + 0.60f + 1.0f,
		-0.895f
	);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	SetShaderMaterial("screen");
	SetShaderTexture("galaxy");
	// UV scale (1, 1) = show the full galaxy image once across the face
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	// ============================================================
	// PART 11A: KEYBOARD BODY (STEEL TEXTURE - BOX) [FINAL PROJECT]
	// ============================================================
	// The outer body of the keyboard - the aluminum tray that the keys
	// sit in. Same placement and material as the monitor body so the
	// keyboard reads as part of the same "Apple ecosystem" visually.
	//
	// SHAPE: Box
	// MATERIAL: plastic (cool silver aluminum Phong values)
	// TEXTURE: steel (brushed aluminum pattern)
	//
	// DIMENSIONS RATIONALE:
	// 2.5 x 0.08 x 0.7 matches the proportions of a typical Apple Magic
	// Keyboard: wide and shallow, almost flat. Making it any thicker
	// would make it read as a book rather than a keyboard.
	//
	// Transformations applied:
	// - SCALE:  2.5 x 0.08 x 0.7
	// - ROTATE: None
	// - TRANSLATE: Center-front on the desk, aligned with the monitor X
	// ============================================================
	scaleXYZ = glm::vec3(2.5f, 0.08f, 0.7f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Y = desktop surface + half scale-Y so bottom rests on desk
	positionXYZ = glm::vec3(0.5f, desktopSurfaceY + 0.04f, 1.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// Same brushsteel treatment as the monitor body for visual
	// consistency. UV scale (2, 1) tiles horizontally to match the
	// keyboard's wide proportions.
	SetShaderMaterial("plastic");
	SetShaderTexture("steel");
	SetTextureUVScale(2.0f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	// ============================================================
	// PART 11B: KEYBOARD KEYS CLUSTER (STEEL TEXTURE - BOX) [FINAL PROJECT]
	// ============================================================
	// A smaller inset box sitting on top of the keyboard body. This raised
	// area represents the cluster of physical keys rising above the
	// aluminum tray. Same two-box approach as the monitor (frame + screen):
	// the outer piece establishes the object's overall shape, and the
	// inner piece adds the recessed/raised detail that sells it as a
	// real object rather than a smooth slab.
	//
	// SHAPE: Box (already loaded)
	// MATERIAL: plastic (matches keyboard body)
	// TEXTURE: steel (shared with keyboard body for now - can be swapped
	//          for a dedicated keys texture later without touching any
	//          other code)
	//
	// DIMENSIONS RATIONALE:
	// 2.3 x 0.04 x 0.55 leaves a 0.1-unit border of body visible around
	// the key cluster on the X axis, and a 0.075-unit border on the Z
	// axis. The key cluster is 0.04 tall - twice as tall as half the
	// body's thickness - so it protrudes noticeably above the body surface.
	//
	// Y POSITIONING:
	// Keyboard body top surface = body center Y (desktopSurfaceY + 0.04)
	//                           + half body scale Y (0.04)
	//                           = desktopSurfaceY + 0.08
	// Keys inner box needs its BOTTOM at that Y value, so its CENTER is
	//   body top + half inner scale Y = (desktopSurfaceY + 0.08) + 0.02
	//                                 = desktopSurfaceY + 0.10
	//
	// Transformations applied:
	// - SCALE:  2.3 x 0.04 x 0.55 (slightly smaller than body, sits on top)
	// - ROTATE: None
	// - TRANSLATE: Centered on the keyboard body in X/Z, resting on its top
	// ============================================================
	scaleXYZ = glm::vec3(2.3f, 0.04f, 0.55f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Same X/Z as body; Y placed so the inner box bottom sits flush with
	// the body top surface
	positionXYZ = glm::vec3(0.5f, desktopSurfaceY + 0.10f, 1.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	SetShaderMaterial("plastic");
	SetShaderTexture("steel");
	SetTextureUVScale(2.0f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	// ============================================================
	// PART 12: MOUSE (PLASTIC - SPHERE, SCALED FLAT) [FINAL PROJECT]
	// ============================================================
	// Desktop mouse to the right of the keyboard. A unit sphere squashed
	// on the Y axis produces a low dome shape - the same silhouette as
	// the Apple Magic Mouse in the reference photo.
	//
	// SHAPE: Sphere (newly added for final project)
	// MATERIAL: plastic (matches keyboard and monitor)
	//
	// NON-UNIFORM SCALE CHOICE:
	// Scaling a sphere non-uniformly (0.25 wide x 0.12 tall x 0.35 deep)
	// creates an ellipsoid. The elongated Z axis makes it longer
	// front-to-back than it is wide, which matches how a real mouse sits
	// under your hand.
	//
	// Transformations applied:
	// - SCALE:  0.25 x 0.12 x 0.35 (flat and slightly elongated)
	// - ROTATE: None
	// - TRANSLATE: Right of keyboard, resting on desktop
	// ============================================================
	scaleXYZ = glm::vec3(0.25f, 0.12f, 0.35f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Sphere center must be half its Y-scale above the desktop surface
	positionXYZ = glm::vec3(2.5f, desktopSurfaceY + 0.12f, 1.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	SetShaderMaterial("plastic");
	SetShaderColor(0.72f, 0.74f, 0.78f, 1.0f);

	m_basicMeshes->DrawSphereMesh();
}