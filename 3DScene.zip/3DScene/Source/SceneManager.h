///////////////////////////////////////////////////////////////////////////////
// SceneManager.h
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//
//  STUDENT: Nathan Perry
//  ASSIGNMENT: Final Project - 3D Desk Scene
//  DESCRIPTION: Final project scene built across Milestones 2-5 and expanded
//               for submission. The desk (box + plane geometry) from earlier
//               milestones now has desktop accessories added: an iMac monitor
//               (box + tapered cylinder + box), a keyboard (box), and a mouse
//               (sphere). A third warm amber overhead light joins the original
//               key + fill pair for the final lighting mood. Existing material
//               and light method declarations below still apply unchanged -
//               the final submission adds "plastic" and "screen" materials
//               and a third active light slot, but does not change the method
//               surface area of this class.
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"

#include <string>
#include <vector>

/***********************************************************
 *  SceneManager
 *
 *  This class contains the code for preparing and rendering
 *  3D scenes, including the shader settings.
 ***********************************************************/
class SceneManager
{
public:
	// constructor
	SceneManager(ShaderManager* pShaderManager);
	// destructor
	~SceneManager();

	struct TEXTURE_INFO
	{
		std::string tag;
		uint32_t ID;
	};

	struct OBJECT_MATERIAL
	{
		float ambientStrength;
		glm::vec3 ambientColor;
		glm::vec3 diffuseColor;
		glm::vec3 specularColor;
		float shininess;
		std::string tag;
	};

private:
	// pointer to shader manager object
	ShaderManager* m_pShaderManager;
	// pointer to basic shapes object
	ShapeMeshes* m_basicMeshes;
	// total number of loaded textures
	int m_loadedTextures = 0;
	// loaded textures info
	TEXTURE_INFO m_textureIDs[16] = {};
	// defined object materials
	std::vector<OBJECT_MATERIAL> m_objectMaterials;

	// load texture images and convert to OpenGL texture data
	bool CreateGLTexture(const char* filename, std::string tag);
	// bind loaded OpenGL textures to slots in memory
	void BindGLTextures();
	// free the loaded OpenGL textures
	void DestroyGLTextures();
	// find a loaded texture by tag
	int FindTextureID(std::string tag);
	int FindTextureSlot(std::string tag);
	// find a defined material by tag
	bool FindMaterial(std::string tag, OBJECT_MATERIAL& material);

	// =========================================================================
	// TEXTURE LOADING (ADDED FOR MILESTONE FOUR)
	// =========================================================================
	// This method loads all texture images needed for the scene.
	// It is called by PrepareScene() before mesh loading.
	void LoadSceneTextures();

	// =========================================================================
	// LIGHTING SETUP (ADDED FOR MILESTONE FIVE)
	// =========================================================================
	// DefineObjectMaterials() populates m_objectMaterials with per-surface
	// Phong material data (ambient / diffuse / specular / shininess). Each
	// entry is keyed by a string tag that RenderScene() passes to
	// SetShaderMaterial() just before drawing a shape, so each surface
	// reflects light according to what it is made of (stone, wood, metal).
	//
	// SetupSceneLights() pushes the light source data into the fragment
	// shader's lightSources[] uniform array and turns on the bUseLighting
	// flag. Both methods are called once from PrepareScene() because the
	// materials and lights in this scene are static - they do not change
	// frame to frame, so there is no need to re-send the uniforms every
	// render pass.
	void DefineObjectMaterials();
	void SetupSceneLights();

	// set the transformation values 
	// into the transform buffer
	void SetTransformations(
		glm::vec3 scaleXYZ,
		float XrotationDegrees,
		float YrotationDegrees,
		float ZrotationDegrees,
		glm::vec3 positionXYZ);

	// set the color values into the shader
	void SetShaderColor(
		float redColorValue,
		float greenColorValue,
		float blueColorValue,
		float alphaValue);

	// set the texture data into the shader
	void SetShaderTexture(
		std::string textureTag);

	// set the UV scale for the texture mapping
	void SetTextureUVScale(
		float u, float v);

	// set the object material into the shader
	void SetShaderMaterial(
		std::string materialTag);

public:

	// The following methods are for the students to 
	// customize for their own 3D scene
	void PrepareScene();
	void RenderScene();

};