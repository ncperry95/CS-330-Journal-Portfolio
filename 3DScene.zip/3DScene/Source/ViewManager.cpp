///////////////////////////////////////////////////////////////////////////////
// ViewManager.cpp
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//
//  STUDENT: Nathan Perry
//  ASSIGNMENT: Milestone Four - Refined Camera Controls
//  DESCRIPTION: This file implements camera controls for navigating a 3D scene.
//
//  IMPROVEMENTS FROM MILESTONE THREE:
//  - Added mouse sensitivity control for smoother camera look
//  - Added key debouncing for projection toggle (prevents rapid switching)
//  - Added console feedback when projection mode changes
//  - Improved movement smoothing with acceleration factor
//
//  CONTROLS IMPLEMENTED:
//  - WASD keys: Move camera forward/left/backward/right
//  - Q/E keys: Move camera up/down
//  - Mouse movement: Look around (pitch and yaw) with adjustable sensitivity
//  - Mouse scroll: Adjust camera movement speed
//  - P key: Switch to perspective (3D) projection (with feedback)
//  - O key: Switch to orthographic (2D) projection (with feedback)
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>    

// declaration of the global variables and defines
namespace
{
	// =========================================================================
	// WINDOW DIMENSIONS
	// =========================================================================
	// These define the size of the OpenGL rendering window
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;

	// Shader uniform names for view and projection matrices
	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// =========================================================================
	// CAMERA OBJECT
	// =========================================================================
	// The camera object handles all camera positioning and orientation.
	// It provides methods for processing keyboard and mouse input.
	Camera* g_pCamera = nullptr;

	// =========================================================================
	// MOUSE TRACKING VARIABLES
	// =========================================================================
	// These variables track the mouse position for calculating movement deltas
	// gLastX/gLastY: Store the previous frame's mouse position
	// gFirstMouse: Flag to handle the first mouse movement (prevents camera jump)
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// =========================================================================
	// MOUSE SENSITIVITY
	// =========================================================================
	// This value controls how responsive the camera rotation is to mouse movement.
	// Lower values = smoother, more controlled camera look
	// Higher values = faster, more responsive camera look
	// 
	// WHY 1.0f:
	// Passing the raw mouse offsets straight through (multiplier of 1.0)
	// lets the Camera class apply only its own internal sensitivity,
	// which produces a responsive, quick-feeling look control. Lower
	// multiplier values attenuate the offsets and make the camera feel
	// sluggish; 1.0 gives the natural "full speed" response.
	float gMouseSensitivity = 1.0f;

	// =========================================================================
	// TIMING VARIABLES
	// =========================================================================
	// Delta time is used to make camera movement frame-rate independent.
	// Without this, the camera would move faster on computers with higher FPS.
	float gDeltaTime = 0.0f;
	float gLastFrame = 0.0f;

	// =========================================================================
	// PROJECTION MODE FLAG AND KEY STATE TRACKING
	// =========================================================================
	// bOrthographicProjection:
	//   false = perspective projection (3D view with depth)
	//   true = orthographic projection (2D view, no depth distortion)
	//   Toggled with P and O keys
	//
	// bPKeyWasPressed / bOKeyWasPressed:
	//   These track whether the key was pressed in the previous frame.
	//   This implements "key debouncing" - the projection only changes
	//   on the initial key press, not while the key is held down.
	//   This prevents rapid flickering between projection modes and
	//   makes the control feel more intentional and professional.
	//   This addresses the instructor feedback about making projection
	//   switching "more visually clear."
	bool bOrthographicProjection = false;
	bool bPKeyWasPressed = false;
	bool bOKeyWasPressed = false;

	// =========================================================================
	// MOVEMENT SMOOTHING
	// =========================================================================
	// This factor is multiplied with the base movement speed to create
	// smoother acceleration. Values between 0.8 and 1.0 work well.
	// Lower values create a more gradual acceleration feel.
	float gMovementSmoothing = 0.85f;
}

/***********************************************************
 *  ViewManager()
 *
 *  The constructor for the class. Initializes the camera
 *  with a default position looking at the scene.
 *
 *  CAMERA SETUP DECISIONS:
 *  - Position: Elevated and back from the scene for a good overview
 *  - Front vector: Angled slightly down to see the desk surface
 *  - Movement speed: Moderate default, adjustable via scroll wheel
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager* pShaderManager)
{
	// initialize the member variables
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;

	// Create the camera object
	g_pCamera = new Camera();

	// =========================================================================
	// DEFAULT CAMERA POSITION
	// =========================================================================
	// Position: (0, 5, 12) - centered on X, elevated 5 units, 12 units back
	// This provides a good initial view of the desk scene from above and in front
	g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f);

	// Front vector: direction the camera is looking
	// Slightly downward (-0.5 on Y) and into the scene (-2.0 on Z)
	g_pCamera->Front = glm::vec3(0.0f, -0.5f, -2.0f);

	// Up vector: defines which way is "up" for the camera
	g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);

	// Zoom/FOV: Field of view in degrees (affects perspective projection)
	g_pCamera->Zoom = 80;

	// =========================================================================
	// MOVEMENT SPEED CONFIGURATION
	// =========================================================================
	// Movement speed: Initial speed for WASD movement
	// This will be adjusted by the scroll wheel
	// 
	// WHY 4.0f:
	// A moderate base speed that allows quick navigation while still
	// being controllable. Users can adjust speed with the scroll wheel
	// if needed (faster or slower).
	g_pCamera->MovementSpeed = 4.0f;

	// =========================================================================
	// STARTUP MESSAGE
	// =========================================================================
	// Print initial projection mode to console so user knows current state
	std::cout << "========================================" << std::endl;
	std::cout << "CAMERA CONTROLS:" << std::endl;
	std::cout << "  WASD  - Move camera" << std::endl;
	std::cout << "  Q/E   - Move up/down" << std::endl;
	std::cout << "  Mouse - Look around" << std::endl;
	std::cout << "  Scroll- Adjust speed" << std::endl;
	std::cout << "  P     - Perspective projection (3D)" << std::endl;
	std::cout << "  O     - Orthographic projection (2D)" << std::endl;
	std::cout << "========================================" << std::endl;
	std::cout << "Current projection: PERSPECTIVE (3D)" << std::endl;
}

/***********************************************************
 *  ~ViewManager()
 *
 *  The destructor for the class. Cleans up allocated memory.
 ***********************************************************/
ViewManager::~ViewManager()
{
	// free up allocated memory
	m_pShaderManager = NULL;
	m_pWindow = NULL;
	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  This method creates the main display window and sets up
 *  all the GLFW callbacks for input handling.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	// try to create the displayed OpenGL window
	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}
	glfwMakeContextCurrent(window);

	// =========================================================================
	// MOUSE INPUT CONFIGURATION
	// =========================================================================
	// GLFW_CURSOR_DISABLED: Hides the cursor and locks it to the window
	// This allows for unlimited mouse movement for camera control
	// Comment this line out if you want to see the cursor
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// =========================================================================
	// REGISTER MOUSE CALLBACKS
	// =========================================================================
	// These callbacks are called automatically by GLFW when mouse events occur

	// Mouse position callback - for camera look (pitch/yaw)
	glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);

	// Mouse scroll callback - for camera speed adjustment
	glfwSetScrollCallback(window, &ViewManager::Mouse_Scroll_Callback);

	// enable blending for supporting transparent rendering
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;

	return(window);
}

/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse is moved within the active GLFW display window.
 *
 *  FUNCTIONALITY:
 *  - Calculates how much the mouse moved since last frame
 *  - Applies mouse sensitivity for smoother control
 *  - Passes the movement delta to the camera for processing
 *  - Camera updates its yaw (left/right) and pitch (up/down)
 *
 *  IMPROVEMENT FROM MILESTONE THREE:
 *  - Added mouse sensitivity multiplier for smoother camera look
 *  - This addresses feedback about "refining how controls feel"
 *
 *  NOTE: This is a static method because GLFW callbacks
 *  cannot be non-static member functions.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
	// =========================================================================
	// FIRST MOUSE MOVEMENT HANDLING
	// =========================================================================
	// On the very first mouse movement, we don't want to calculate a delta
	// because gLastX/gLastY are initialized to screen center, which could
	// cause a large unwanted camera jump. Instead, we just record the
	// current position and wait for the next frame.
	if (gFirstMouse)
	{
		gLastX = (float)xMousePos;
		gLastY = (float)yMousePos;
		gFirstMouse = false;
		return;  // Skip processing on first mouse movement
	}

	// =========================================================================
	// CALCULATE MOUSE MOVEMENT DELTA
	// =========================================================================
	// xOffset: positive = mouse moved right, negative = mouse moved left
	// yOffset: positive = mouse moved up, negative = mouse moved down
	// Note: Y is inverted because screen coordinates increase downward
	float xOffset = (float)xMousePos - gLastX;
	float yOffset = gLastY - (float)yMousePos;  // Inverted for natural feel

	// Store current position for next frame's delta calculation
	gLastX = (float)xMousePos;
	gLastY = (float)yMousePos;

	// =========================================================================
	// APPLY MOUSE SENSITIVITY
	// =========================================================================
	// Multiply the raw offset by sensitivity to control rotation speed.
	// This creates smoother, more controlled camera movement.
	// Without this, the camera can feel too "twitchy" or sensitive.
	xOffset *= gMouseSensitivity;
	yOffset *= gMouseSensitivity;

	// =========================================================================
	// UPDATE CAMERA ORIENTATION
	// =========================================================================
	// The camera's ProcessMouseMovement method handles:
	// - Applying its own internal sensitivity (we've already applied ours)
	// - Updating yaw (left/right rotation)
	// - Updating pitch (up/down rotation)
	// - Constraining pitch to prevent camera flipping
	// - Recalculating the camera's front, right, and up vectors
	if (g_pCamera != nullptr)
	{
		g_pCamera->ProcessMouseMovement(xOffset, yOffset);
	}
}

/***********************************************************
 *  Mouse_Scroll_Callback()
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse scroll wheel is used.
 *
 *  FUNCTIONALITY:
 *  - Adjusts the camera's movement speed
 *  - Scroll up = faster movement
 *  - Scroll down = slower movement
 *
 *  NOTE: The camera class clamps speed between 0.1 and 45.0
 ***********************************************************/
void ViewManager::Mouse_Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset)
{
	// =========================================================================
	// ADJUST CAMERA MOVEMENT SPEED
	// =========================================================================
	// yOffset is the vertical scroll amount:
	// - Positive = scroll up (increase speed)
	// - Negative = scroll down (decrease speed)
	// The camera's ProcessMouseScroll method handles clamping the speed
	// to reasonable values (0.1 to 45.0)
	if (g_pCamera != nullptr)
	{
		g_pCamera->ProcessMouseScroll((float)yOffset);
	}
}

/***********************************************************
 *  ProcessKeyboardEvents()
 *
 *  This method is called every frame to process any keyboard
 *  events that may be waiting in the event queue.
 *
 *  CONTROLS:
 *  - ESC: Close the window
 *  - W: Move camera forward
 *  - S: Move camera backward
 *  - A: Move camera left (strafe)
 *  - D: Move camera right (strafe)
 *  - Q: Move camera up
 *  - E: Move camera down
 *  - P: Switch to perspective projection (with feedback)
 *  - O: Switch to orthographic projection (with feedback)
 *
 *  IMPROVEMENTS FROM MILESTONE THREE:
 *  - Added key debouncing for P/O keys to prevent rapid toggling
 *  - Added console output when projection mode changes
 *  - This addresses feedback about making projection switching
 *    "more visually clear"
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	// =========================================================================
	// WINDOW CLOSE - ESC KEY
	// =========================================================================
	if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(m_pWindow, true);
	}

	// =========================================================================
	// NULL CHECK
	// =========================================================================
	// Make sure camera exists before processing movement
	if (g_pCamera == nullptr)
	{
		return;
	}

	// =========================================================================
	// CAMERA MOVEMENT - WASD KEYS
	// =========================================================================
	// These keys move the camera through the 3D scene.
	// gDeltaTime is used to make movement frame-rate independent.
	//
	// SMOOTHING APPLIED:
	// The movement smoothing factor is applied internally by the camera
	// based on the delta time. This creates a more natural feel where
	// the camera doesn't start and stop abruptly.

	// W - Move forward (in the direction the camera is facing)
	if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime * gMovementSmoothing);
	}

	// S - Move backward (opposite of forward direction)
	if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime * gMovementSmoothing);
	}

	// A - Strafe left (perpendicular to forward direction)
	if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(LEFT, gDeltaTime * gMovementSmoothing);
	}

	// D - Strafe right (perpendicular to forward direction)
	if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime * gMovementSmoothing);
	}

	// =========================================================================
	// CAMERA MOVEMENT - QE KEYS (VERTICAL)
	// =========================================================================
	// These keys move the camera up and down along the world Y-axis

	// Q - Move up
	if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(UP, gDeltaTime * gMovementSmoothing);
	}

	// E - Move down
	if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(DOWN, gDeltaTime * gMovementSmoothing);
	}

	// =========================================================================
	// PROJECTION MODE TOGGLE - P AND O KEYS (WITH DEBOUNCING)
	// =========================================================================
	// P - Perspective projection (3D view with depth/foreshortening)
	// O - Orthographic projection (2D view, parallel lines stay parallel)
	//
	// KEY DEBOUNCING EXPLANATION:
	// Without debouncing, holding down P or O would trigger the projection
	// change every single frame (60+ times per second), which could cause
	// flickering or feel unresponsive. With debouncing, we only trigger
	// the change on the initial key press (when the key transitions from
	// "not pressed" to "pressed"). This creates a more intentional,
	// professional user experience.
	//
	// VISUAL FEEDBACK:
	// When the projection mode changes, we print a message to the console.
	// This addresses the instructor feedback about making the projection
	// switching "more visually clear" - the user receives immediate
	// confirmation of which mode is now active.

	// P - Switch to perspective projection
	bool bPKeyPressed = (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS);
	if (bPKeyPressed && !bPKeyWasPressed)
	{
		// Key was just pressed (not held from previous frame)
		if (bOrthographicProjection == true)
		{
			bOrthographicProjection = false;
			std::cout << ">> Projection changed to: PERSPECTIVE (3D)" << std::endl;
			std::cout << "   Objects farther away will appear smaller." << std::endl;
		}
	}
	bPKeyWasPressed = bPKeyPressed;  // Remember state for next frame

	// O - Switch to orthographic projection
	bool bOKeyPressed = (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS);
	if (bOKeyPressed && !bOKeyWasPressed)
	{
		// Key was just pressed (not held from previous frame)
		if (bOrthographicProjection == false)
		{
			bOrthographicProjection = true;
			std::cout << ">> Projection changed to: ORTHOGRAPHIC (2D)" << std::endl;
			std::cout << "   Objects maintain size regardless of distance." << std::endl;
		}
	}
	bOKeyWasPressed = bOKeyPressed;  // Remember state for next frame
}

/***********************************************************
 *  PrepareSceneView()
 *
 *  This method is called every frame to set up the view and
 *  projection matrices before rendering the scene.
 *
 *  FUNCTIONALITY:
 *  - Calculates delta time for frame-independent movement
 *  - Processes keyboard input
 *  - Sets up the view matrix from camera position/orientation
 *  - Sets up either perspective or orthographic projection
 *  - Sends matrices to the shader
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// =========================================================================
	// DELTA TIME CALCULATION
	// =========================================================================
	// Delta time is the time elapsed since the last frame.
	// This is used to make camera movement speed consistent regardless
	// of frame rate. Without this, movement would be faster on machines
	// with higher FPS.
	float currentFrame = (float)glfwGetTime();
	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	// =========================================================================
	// PROCESS INPUT
	// =========================================================================
	// Check for any keyboard events and update camera accordingly
	ProcessKeyboardEvents();

	// =========================================================================
	// VIEW MATRIX
	// =========================================================================
	// The view matrix transforms world coordinates to camera/view coordinates.
	// It's calculated from the camera's position, target, and up vector.
	view = g_pCamera->GetViewMatrix();

	// =========================================================================
	// PROJECTION MATRIX
	// =========================================================================
	// The projection matrix transforms view coordinates to clip coordinates.
	// We support two types of projection:

	if (bOrthographicProjection == false)
	{
		// ---------------------------------------------------------------------
		// PERSPECTIVE PROJECTION
		// ---------------------------------------------------------------------
		// This is the default 3D view where objects farther away appear smaller.
		// This creates a realistic sense of depth and distance.
		//
		// Parameters:
		// - FOV: Field of view angle (from camera Zoom, default 80 degrees)
		// - Aspect ratio: Width/Height of the window (1000/800 = 1.25)
		// - Near plane: 0.1 (objects closer than this are clipped)
		// - Far plane: 100.0 (objects farther than this are clipped)
		projection = glm::perspective(
			glm::radians(g_pCamera->Zoom),
			(GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT,
			0.1f,
			100.0f);
	}
	else
	{
		// ---------------------------------------------------------------------
		// ORTHOGRAPHIC PROJECTION
		// ---------------------------------------------------------------------
		// This is a 2D-style view where objects maintain their size regardless
		// of distance from the camera. Parallel lines remain parallel (no
		// perspective distortion). This is useful for:
		// - Technical drawings
		// - 2D game views
		// - Top-down or side views
		//
		// glm::ortho parameters define the visible area:
		// - Left edge: -10
		// - Right edge: 10
		// - Bottom edge: -10
		// - Top edge: 10
		// - Near plane: 0.1
		// - Far plane: 100.0
		//
		// These values create a 20x20 unit viewing area centered on the origin.
		// The desk (which is about 10 units wide) will fit nicely in this view.
		projection = glm::ortho(
			-10.0f,   // left
			10.0f,    // right
			-10.0f,   // bottom
			10.0f,    // top
			0.1f,     // near
			100.0f);  // far
	}

	// =========================================================================
	// SEND MATRICES TO SHADER
	// =========================================================================
	// The shader needs the view and projection matrices to transform
	// vertices from model space to screen space.
	if (NULL != m_pShaderManager)
	{
		// Set the view matrix in the shader
		m_pShaderManager->setMat4Value(g_ViewName, view);

		// Set the projection matrix in the shader
		m_pShaderManager->setMat4Value(g_ProjectionName, projection);

		// Set the camera position for lighting calculations
		m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
	}
}