///////////////////////////////////////////////////////////////////////////////
// ViewManager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//
//  STUDENT: Nathan Perry
//  ASSIGNMENT: Milestone Three - Camera Navigation
//  DESCRIPTION: Added mouse scroll callback for camera speed control and
//               documentation for the P/O orthographic projection toggle.
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "camera.h"

// GLFW library
#include "GLFW/glfw3.h" 

class ViewManager
{
public:
	// constructor
	ViewManager(
		ShaderManager* pShaderManager);
	// destructor
	~ViewManager();

	// =========================================================================
	// MOUSE CALLBACKS
	// =========================================================================
	// These static methods are called automatically by GLFW when mouse events
	// occur. They must be static because GLFW is a C library and cannot call
	// C++ member functions directly.
	// =========================================================================

	// Mouse position callback - called when the mouse moves
	// Used for camera look (pitch/yaw) control
	static void Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos);

	// Mouse scroll callback - called when the scroll wheel is used
	// Used for adjusting camera movement speed
	static void Mouse_Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset);

private:
	// pointer to shader manager object
	ShaderManager* m_pShaderManager;
	// active OpenGL display window
	GLFWwindow* m_pWindow;

	// process keyboard events for interaction with the 3D scene
	void ProcessKeyboardEvents();

public:
	// create the initial OpenGL display window
	GLFWwindow* CreateDisplayWindow(const char* windowTitle);

	// prepare the conversion from 3D object display to 2D scene display
	void PrepareSceneView();
};